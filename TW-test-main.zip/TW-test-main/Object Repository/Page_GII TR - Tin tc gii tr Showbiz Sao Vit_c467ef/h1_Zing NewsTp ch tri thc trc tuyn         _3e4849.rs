<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Zing NewsTp ch tri thc trc tuyn         _3e4849</name>
   <tag></tag>
   <elementGuidId>ba5c374c-a964-4a4a-98de-da99de187560</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h1.logo</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//header[@id='zing-header']/div/h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>32d712fb-5175-4401-af64-25bf14bc59ab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>logo</value>
      <webElementGuid>4ef224c1-dba5-4324-95d5-9d597736603d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            Zing NewsTạp chí tri thức trực tuyến
                    v1.6.81
                
        </value>
      <webElementGuid>b9b507b1-e4e6-4e88-9801-089aacc3760f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;zing-header&quot;)/div[@class=&quot;page-wrapper&quot;]/h1[@class=&quot;logo&quot;]</value>
      <webElementGuid>36ca3553-91b1-432c-9967-7597c58f6aa1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='zing-header']/div/h1</value>
      <webElementGuid>ad61be32-4fa8-4ca5-a4e1-eee9e3fee473</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Adtima'])[1]/following::h1[1]</value>
      <webElementGuid>1b474396-a54e-436e-847d-4cfad45f0844</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>0171e3f1-6f22-4683-8fcd-8c82a83e5b88</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = '
            Zing NewsTạp chí tri thức trực tuyến
                    v1.6.81
                
        ' or . = '
            Zing NewsTạp chí tri thức trực tuyến
                    v1.6.81
                
        ')]</value>
      <webElementGuid>6051ab20-c858-41e4-aebf-f34ae9060294</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
