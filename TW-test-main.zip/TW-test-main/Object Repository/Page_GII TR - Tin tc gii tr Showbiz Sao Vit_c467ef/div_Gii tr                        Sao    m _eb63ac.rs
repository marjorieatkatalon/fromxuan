<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Gii tr                        Sao    m _eb63ac</name>
   <tag></tag>
   <elementGuidId>bf741421-76fe-473d-91e9-9241b7b70c33</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#page-category > div.page-wrapper</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//body[@id='page-category']/div[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>ea698cde-775b-4714-a074-298a8fbf0881</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>page-wrapper</value>
      <webElementGuid>93b5872e-ffea-4735-b5da-4ff00f4ca6b5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
    
    
        Giải trí
    
    
    
        






    Sao




    Âm nhạc




    Phim ảnh




    Thời trang




    
    


    
     

    
        
            
                
                
                    



        
            
            
        
    
    
        
            Quản lý: 'Ti Ti không thể có số tiền lớn như trong hình ở sòng bài'
        
        
            
                4 giờ trước
                06:16
                8/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Quản lý xác nhận Ti Ti xuất hiện ở sòng bài Campuchia hồi tháng 7 nhưng anh không biết chơi, chỉ ngồi trông hộ bạn và cũng không có nhiều tiền như vậy.
        
    





                
                
                
                
                    



        
            
            
        
    
    
        
            Tình bạn giữa Selena Gomez và người cho thận trước khi rạn nứt
        
        
            
                39 phút trước
                09:45
                8/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Trả lời phỏng vấn mới nhất, Selena Gomez nói chỉ có Taylor Swift là bạn thân trong ngành, hoàn toàn không đề cập Francia Raisa - nữ diễn viên đã hiến cho cô quả thận năm 2017.
        
    




        
            
            
        
    
    
        
            Hiện trường nơi Aaron Carter qua đời
        
        
            
                1 giờ trước
                09:09
                8/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Nguyên nhân cái chết của Aaron Carter chưa được công bố, song cảnh sát đã phát hiện lon khí nén và thuốc kê đơn trong phòng tắm, phòng ngủ của nam ca sĩ.
        
    





                
                
            
            
            
            
                



        
            
            
        
    
    
        
            Pique hôn bạn gái sau trận đấu cuối cùng
        
        
            
                1 giờ trước
                09:21
                8/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Pique vừa chơi trận đấu cuối cùng tại Camp Nou với tư cách là cầu thủ của Barca. Sau khi bước lên khán đài, anh ôm hôn bạn gái.
        
    




        
            
            
        
    
    
        
            Chân Tử Đan gây bức xúc
        
        
            
                2 giờ trước
                08:48
                8/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Tác phẩm &quot;Giải cứu&quot; của Chân Tử Đan thất bại nặng nề về doanh thu lẫn chất lượng. Phản ứng dửng dưng của anh trên cương vị diễn viên chính và giám đốc sản xuất gây bức xúc.
        
    




        
            
            
        
    
    
        
            Trang Tư Mẫn ly hôn chồng doanh nhân sau 2 năm cưới
        
        
            
                2 giờ trước
                08:40
                8/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            
            
        
        Vợ chồng nữ diễn viên rạn nứt vì vấn đề nơi ở. Trang Tư Mẫn cho biết không yêu cầu doanh nhân Đài Loan chia tài sản hay trợ cấp sau ly hôn.
        
    




        
            
            
        
    
    
        
            BlackPink gây tranh cãi vì liên tục mặc đồ hở hang
        
        
            
                4 giờ trước
                06:23
                8/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            
            
        
        Khán giả đang chỉ trích việc các thành viên BlackPink thời gian gần đây thường xuyên mặc đồ sexy quá mức, đặc biệt trong đêm nhạc của nhóm.
        
    





            
            
        
    


    
    
    
    
    
    
    
    
    
    

    
    

    
        MỚI NHẤT
    
    

        
            



        
            
            
        
    
    
        
            Cha Quan Hiểu Đồng bức xúc vì tin đồn đòi quà đính hôn 100 triệu NDT
        
        
            
                10 giờ trước
                00:04
                8/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            
            
        
        Tin tức Quan Hiểu Đồng - Lộc Hàm đã đăng ký kết hôn gây xôn xao dư luận Trung Quốc. Cha nữ diễn viên lên tiếng phủ nhận và nói tin đồn quá cường điệu và thất thiệt.
        
    




        
            
            
        
    
    
        
            Ca sĩ Ti Ti (HKT) lên tiếng thông tin đánh bài tại sòng bạc Campuchia
        
        
            
                12 giờ trước
                22:16
                7/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            27
            
        
        Nam ca sĩ Ti Ti xác nhận hình ảnh thanh niên ngồi ở sòng bạc Campuchia là mình. Tuy nhiên, anh khẳng định bản thân không đánh bạc mà chỉ &quot;ngồi giữ tiền giùm bạn&quot;.
        
    




        
            
            
        
    
    
        
            Selena Gomez bị chỉ trích vô ơn với người cho thận
        
        
            
                12 giờ trước
                22:05
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            1
            
        
        Tình cảm giữa Selena Gomez và Francia Raisa - người đã hiến thận cho cô - rạn nứt sau khi nữ ca sĩ khẳng định chỉ có Taylor Swift là bạn thân trong ngành giải trí.
        
    




        
            
            
        
    
    
        
            Nhiều nghệ sĩ Hàn bị yêu cầu rời khỏi ngành giải trí
        
        
            
                13 giờ trước
                21:23
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            2
            
        
        MC Ding Dong, Lizzy và Yoon Je Moon đang bị truyền thông Hàn Quốc chỉ trích vì trở lại ngành giải trí. Họ từng lái xe trong tình trạng say rượu.
        
    




        
            
            
        
    
    
        
            CEO nữ từ chức sau khi bạo hành nhóm nhạc nam
        
        
            
                14 giờ trước
                20:48
                7/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            
            
        
        Công ty thông báo nữ CEO đã nghỉ việc nhưng người hâm mộ vẫn tỏ ra nghi hoặc và cho rằng đây chỉ là động thái trấn an dư luận.
        
    




        
            
            
        
    
    
        
            Điều cấm kỵ khi phối đồ đi xem World Cup 2022
        
        
            
                14 giờ trước
                20:22
                7/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            
            
        
        Khi xếp hành lý để chuẩn bị đi xem World Cup, bạn cần chú ý các loại trang phục được mặc để nghĩ cách phối phù hợp.
        
    




        
            
            
        
    
    
        
            Miss Universe 2021 bị soi vóc dáng đẫy đà
        
        
            
                14 giờ trước
                19:59
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            17
            
        
        Đương kim Miss Universe Harnaaz Sandhu bị soi ngoại hình khi xuất hiện cùng dàn người đẹp Hoa hậu Hoàn vũ.
        
    




        
            
            
        
    
    
        
            Trùm giải trí Tăng Chí Vỹ nổi giận tại trường quay vì bị trêu chọc
        
        
            
                15 giờ trước
                19:31
                7/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            4
            
        
        Tăng Chí Vỹ bực tức với hành động đùa giỡn không đúng lúc của Lâm Mẫn Thông trong quá trình quay show. Ông yêu cầu dừng ghi hình để đồng nghiệp kiểm điểm hành vi.
        
    




        
            
            
        
    
    
        
            'Chu Bá Thông' Tần Hoàng giảm 30 kg để giữ tính mạng
        
        
            
                15 giờ trước
                19:00
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            22
            
        
        Nam diễn viên gạo cội của TVB mắc nhiều bệnh vì nặng đến 127 kg. Thời gian qua, ông tìm mọi cách giảm cân để cải thiện sức khỏe.
        
    




        
            
            
        
    
    
        
            Nghệ sĩ Trung Quốc đang bị tình dục hóa quá mức khi mặc gợi cảm
        
        
            
                16 giờ trước
                18:06
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            2
            
        
        &quot;Phái yếu mặc gợi cảm, trang điểm đẹp chỉ vì muốn thể hiện cá tính, sự tự tin chứ không phải đang khiêu gợi đàn ông&quot;, Tống Vũ Kỳ nêu quan điểm.
        
    




        
            
            
        
    
    
        
            Phụ nữ mang thai có thể thi Hoa hậu Hoàn vũ Philippines
        
        
            
                17 giờ trước
                16:58
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Cuộc thi Hoa hậu Hoàn vũ Philippines 2023 thay đổi tiêu chí so với những mùa trước, không giới hạn chiều cao cũng như tình trạng hôn nhân.
        
    




        
            
            
        
    
    
        
            Kim Kardashian, Selena Gomez và dàn sao mặc đẹp nhất tuần
        
        
            
                19 giờ trước
                15:45
                7/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            
            
        
        Các mẫu váy áo cắt xẻ, bó sát đang phủ sóng trên thảm đỏ. Thiết kế gợi cảm giúp nhiều sao nữ được khen ngợi.
        
    




        
            
            
        
    
    
        
            Người rao bán mũ của Jung Kook (BTS) thú tội
        
        
            
                19 giờ trước
                15:43
                7/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            
            
        
        Trước phản ứng gay gắt của cộng đồng mạng, cựu viên chức Bộ Ngoại giao Hàn Quốc đã gỡ bỏ thông tin rao bán mũ của Jung Kook và tới sở cảnh sát để thú tội.
        
    




        
            
            
        
    
    
        
            Loạt mốt thời trang gây tranh luận của nghệ sĩ
        
        
            
                21 giờ trước
                13:19
                7/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            
            
        
        Năm nay, nhiều mốt thời trang độc đáo được ưa chuộng. Song, nhiều nghệ sĩ cũng gây tranh cãi khi diện đồ xuyên thấu, lộ nội y.
        
    




        
            
            
        
    
    
        
            Gigi Hadid xóa Twitter vì Elon Musk nắm quyền
        
        
            
                22 giờ trước
                12:13
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Sao Hollywood
            
            

            
        
        
            
            
            0
            1
            
        
        Siêu mẫu Gigi Hadid tuyên bố xóa tài khoản Twitter của mình sau khi Elon Musk ngồi lên ghế chủ tịch tập đoàn.
        
    




        
            
            
        
    
    
        
            Lý do Tần Lam chưa kết hôn ở tuổi 43
        
        
            
                24 giờ trước
                10:25
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            12
            
        
        Tần Lam cho biết không mặn mà với chuyện hẹn hò hay hôn nhân. Cô và đối tượng khác giới có xu hướng trở thành bạn tốt của nhau sau một thời gian tìm hiểu.
        
    




        
            
            
        
    
    
        
            'Kẻ độc hành' của Huỳnh Lập - giống Châu Tinh Trì nhưng cũ, kỹ xảo kém
        
        
            
                09:34 7/11/2022
                09:34
                7/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            84
            
        
        Huỳnh Lập tiếp tục sản xuất kiêm đóng chính trong phần tiền truyện của &quot;Pháp sư mù&quot; và &quot;Ai chết giơ tay&quot;. Nam nghệ sĩ áp dụng lại lối pha trò cũ, thiếu sự mới mẻ ở kịch bản.
        
    




        
            
            
        
    
    
        
            Anh trai bật khóc trên sân khấu sau cái chết của Aaron Carter
        
        
            
                09:11 7/11/2022
                09:11
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            8
            
        
        Nick Carter đau buồn khi em trai qua đời. Trước khi Aaron Carter mất, mối quan hệ giữa hai nam ca sĩ không tốt đẹp, thậm chí từng cạch mặt nhau.
        
    




        
            
            
        
    
    
        
            Nữ người mẫu thuộc giới thượng lưu ở Dubai
        
        
            
                08:33 7/11/2022
                08:33
                7/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            
            
        
        LJ Loujain Adada tận hưởng cuộc sống xa hoa với những chuyến du lịch xa xỉ, loạt đồ hiệu đắt đỏ. Cô có ngoại hình ấn tượng cùng gu thời trang gợi cảm.
        
    




        
            
            
        
    
    
        
            Phim của The Rock tiếp tục dẫn đầu phòng vé
        
        
            
                08:27 7/11/2022
                08:27
                7/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            4
            
        
        &quot;Black Adam&quot; duy trì ngôi vương phòng vé nội địa trong tuần thứ ba liên tiếp. Bom tấn do The Rock đóng chính được dự đoán vượt qua thành tích của &quot;Shazam&quot; (2019).
        
    




        
            
            
        
    
    
        
            CEO Phạm Kim Dung: Nam Em từng bị lừa gạt, đòi tiền mua giải
        
        
            
                07:59 7/11/2022
                07:59
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            22
            
        
        Bà Phạm Kim Dung - Chủ tịch công ty Sen Vàng - chia sẻ Nam Em từng rơi vào trường hợp bị kẻ xấu lừa gạt, đặt vấn đề mua giải hoa khôi.
        
    




        
            
            
        
    
    
        
            Chú rể Việt vẫn an toàn khi chọn trang phục cưới
        
        
            
                07:16 7/11/2022
                07:16
                7/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            337
            
        
        Vì ít mặc suit hay vest, nhiều người thường ngại phá vỡ công thức truyền thống. Stylist Khúc Mạnh Quân có nhiều lời khuyên cho nam giới Việt khi chọn đồ cưới.
        
    




        
            
            
        
    
    
        
            Thế khó của Trấn Thành
        
        
            
                06:04 7/11/2022
                06:04
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            6
            
        
        Giới trong nghề nhận định &quot;Bố già&quot; đã đạt được doanh thu &quot;vô tiền khoáng hậu&quot; với hơn 400 tỷ đồng. Dự án phim Tết 2023 của Trấn Thành không dễ vượt qua con số này.
        
    




        
            
            
        
    
    
        
            Sức khỏe hiện tại của 'Khương Tử Nha' Dư Tử Minh
        
        
            
                22:44 6/11/2022
                22:44
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            20
            
        
        Dư Tử Minh là diễn viên gạo cội của TVB từng tham gia nhiều tác phẩm kinh điển. Sức khỏe của ông yếu đi sau cơn đột quỵ hồi đầu năm.
        
    




        
            
            
        
    
    
        
            Nadech Kugimiya và Yaya Urassaya lên kế hoạch kết hôn sau 12 năm yêu
        
        
            
                21:54 6/11/2022
                21:54
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            1
            
        
        Nadech Kugimiya tiết lộ đang chuẩn bị lễ cưới với Yaya Urassaya. Họ là ngôi sao hàng đầu và có thu nhập cao tại Thái Lan.
        
    




        
            
            
        
    
    
        
            Amee, Liên Bỉnh Phát dự lễ cưới Masew
        
        
            
                20:08 6/11/2022
                20:08
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            85
            
        
        Masew tổ chức lễ cưới vào tối 6/11 với sự tham gia của nhiều đồng nghiệp thân thiết như Amee, B Ray, Liên Bỉnh Phát, Đạt G, Quân A.P...
        
    




        
            
            
        
    
    
        
            Trần Phi Vũ chứng tỏ không chỉ mang danh 'con trai Trần Khải Ca'
        
        
            
                19:21 6/11/2022
                19:21
                6/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            
            
        
        Trần Phi Vũ đang được mệnh danh là &quot;bạn trai trong mơ&quot; nhờ vai diễn thiên tài Lý Tuấn trong phim ngôn tình &quot;Chiếc bật lửa và váy công chúa&quot;.
        
    




        
            
            
        
    
    
        
            ‘Virus cuồng loạn’ - bộ phim cẩu thả của điện ảnh Việt
        
        
            
                18:40 6/11/2022
                18:40
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            43
            
        
        Dự án điện ảnh kinh dị đầu tay của đạo diễn trẻ Nhất Duy gây thất vọng vì kịch bản chất lượng thấp cùng phong cách làm phim ngô nghê, thiếu tôn trọng người xem.
        
    




        
            
            
        
    
    
        
            Tranh luận việc nữ ca sĩ 14 tuổi biểu diễn vũ đạo gợi cảm
        
        
            
                15:09 6/11/2022
                15:09
                6/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            1
            
        
        CLASS:y có hai thành viên sinh năm 2008. Do đó, việc nhóm chuyển sang phong cách trưởng thành và có nhiều động tác gợi cảm khiến khán giả tranh luận.
        
    




        
            
            
        
    
    
        
            'Bông hồng lai' Patricia Good và đại gia Thái Lan chuẩn bị cho lễ cưới
        
        
            
                14:20 6/11/2022
                14:20
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            9
            
        
        Patricia Good và doanh nhân giàu có Note Vises đính hôn hồi tháng 6. Họ vừa thực hiện các nghi thức dâng hoa và nhận nước thánh tại chùa.
        
    




        
            
            
        
    
    
        
            Hàng ghế đầu Tuần lễ thời trang có còn mất giá vì TikToker tai tiếng
        
        
            
                12:26 6/11/2022
                12:26
                6/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            8
            
        
        Khách mời tại sự kiện thời trang phụ thuộc vào nhiều nguồn. Bên cạnh đó, ban tổ chức Tuần lễ thời trang khuyến khích không mang những điều quá dị hợm đến sự kiện.
        
    




        
            
            
        
    
    
        
            Ngành giải trí Nhật Bản chấn động vì nam ca sĩ qua đời ở tuổi 19
        
        
            
                11:37 6/11/2022
                11:37
                6/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            12
            
        
        Nikkan Sports đưa tin nam ca sĩ kiêm diễn viên Yoshi bị tai nạn vào sáng 5/11. Vụ việc khiến anh bị thương nặng và qua đời sau đó.
        
    




        
            
            
        
    
    
        
            Aaron Carter - từ 'hoàng tử trong mơ' đến cái chết ở tuổi 35
        
        
            
                11:02 6/11/2022
                11:02
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Sao Hollywood
            
            

            
        
        
            
            
            0
            43
            
        
        Trở thành ngôi sao toàn cầu từ khi còn rất nhỏ, sự nghiệp của Aaron Carter lên &quot;như diều gặp gió&quot;. Tuy nhiên, mặt tối hào quang và bi kịch gia đình khiến anh tụt dốc không phanh.
        
    




        
            
            
        
    
    
        
            Hôn lễ của diễn viên 'Tình dục là chuyện nhỏ' và vợ kém 24 tuổi
        
        
            
                10:26 6/11/2022
                10:26
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Hôn lễ của nam diễn viên Choi Seong Guk diễn ra tối 5/11 tại Jongno-gu. Anh và bạn gái quen nhau một năm trước khi về chung một nhà.
        
    




        
            
            
        
    
    
        
            'Trương Phi' chưa biết 'Quan Vũ' qua đời
        
        
            
                10:15 6/11/2022
                10:15
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Trong &quot;Tam quốc diễn nghĩa&quot;, khi Quan Vũ qua đời, Trương Phi khóc tới ngất. Song, khi &quot;Quan Vũ&quot; Lục Thụ Minh ra đi, người thân không dám báo &quot;Trương Phi&quot; Lý Tĩnh Phi.
        
    




        
            
            
        
    
    
        
            Angelababy khủng hoảng phiên vị
        
        
            
                09:30 6/11/2022
                09:30
                6/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            
            
        
        Angelababy lép vế trước Nhậm Gia Luân trong phim truyền hình mới &quot;Mộ sắc tâm ước&quot;. Điều này khiến người hâm mộ của cô thất vọng.
        
    




        
            
            
        
    
    
        
            Những ngày cuối đời của Aaron Carter
        
        
            
                09:11 6/11/2022
                09:11
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            46
            
        
        Một tháng trước khi mất, Aaron Carter rao bán căn nhà riêng để &quot;bắt đầu chương mới của cuộc đời&quot;. Mối quan hệ của anh và hôn thê cũng trở nên tồi tệ.
        
    




        
            
            
        
    
    
        
            Người đẹp Trà Vinh cao 1,8 m là tân Hoa khôi Nam Bộ 2022
        
        
            
                09:09 6/11/2022
                09:09
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            4
            
        
        Đêm chung kết cuộc thi Hoa khôi Nam Bộ 2022 được tổ chức tại TP Cần Thơ vừa kết thúc tối 5/11. Kết quả thí sinh Lê Thị Kiều Nhung (Trà Vinh) đoạt vương miện hoa khôi.
        
    




        
            
            
        
    
    
        
            Phim đồng tính và mặt tối 'queerbaiting’
        
        
            
                08:31 6/11/2022
                08:31
                6/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            7
            
        
        Từng là một địa hạt cực kỳ nhạy cảm, câu chuyện về cộng đồng LGBTQ+ dần có những bước tiếp cận tiến bộ với khán giả đại chúng.
        
    




        
            
            
        
    
    
        
            Son Heung-min mặc đẹp
        
        
            
                08:09 6/11/2022
                08:09
                6/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            7
            
        
        Không phải ngôi sao giải trí nhưng gu ăn mặc của Son Heung-min chẳng hề kém cạnh. Bên ngoài sân cỏ, anh chính là tín đồ thời trang.
        
    




        
            
            
        
    
    
        
            Aaron Carter qua đời
        
        
            
                08:02 6/11/2022
                08:02
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            76
            
        
        Ca sĩ Aaron Carter qua đời đột ngột tại nhà riêng ở Lancaster, California, Mỹ. Nguyên nhân cái chết của anh vẫn chưa được xác định.
        
    




        
            
            
        
    
    
        
            Tăng Thanh Hà và Louis Nguyễn kỷ niệm 10 năm ngày cưới
        
        
            
                08:02 6/11/2022
                08:02
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            16
            
        
        Vợ chồng Tăng Thanh Hà tổ chức bữa tiệc ấm cúng bên người thân, bạn bè để kỷ niệm 10 năm ngày về chung một nhà.
        
    






            
            
                Xem thêm
            
            
        

        
        
            

            
            
    
    
        
        SIGNATURE SERIES
    
    
    
    



        
            
            10:02
            
            
        
    
    
        
            Ca sĩ Bích Phương: 'Bản chất tôi là người lười biếng'
        
        
            
                06:08 6/12/2021
                06:08
                6/12/2021
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Bích Phương cho biết cô vốn có tính lười, nên trong một năm đầu tiên dịch bệnh diễn ra, nữ ca sĩ chỉ nằm trong nhà và không làm bất cứ việc gì.
        
    




        
            
            12:28
            
            
        
    
    
        
            Erik: 'Tham gia 10 cuộc thi, lần đầu tôi giành quán quân'
        
        
            
                07:33 5/12/2021
                07:33
                5/12/2021
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            
            
        
        Erik vừa giành chiến thắng ở chương trình The Heroes. Nam ca sĩ cho biết anh hạnh phúc khi cuối cùng đã nhận giải quán quân sau nhiều cuộc thi.
        
    




        
            
            14:54
            
            
        
    
    
        
            Ca sĩ Mlee: 'Nếu bạn trai đi quá giới hạn, tôi sẽ chia tay'
        
        
            
                06:20 19/9/2021
                06:20
                19/9/2021
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Mlee cho biết cô yêu hết mình nhưng cũng dứt khoát chia tay nếu bạn trai đi quá giới hạn. Nữ ca sĩ cho biết hiện cô độc thân để dồn thời gian cho công việc.
        
    





    
    
    
    
    Xem thêm

            
            
    
    
        
        Sách Nghệ thuật - Giải trí
    
    
    
    



        
            
            
        
    
    
        
            Bà trùm nội y từng đi giao báo kiếm tiền năm 10 tuổi
        
        
            
                20:18 29/10/2022
                20:18
                29/10/2022
            

            
            
                Xuất bản
            
            

            
            
                Sách hay
            
            

            
        
        
            
            
            0
            
            
        
        “Tôi thuyết phục quầy báo nằm trên cùng con phố cho tôi đi giao báo. Lượng báo phải giao rất nhiều, nhưng tôi rất quyết tâm”, Michelle Mone kể trong cuốn tự truyện.
        
    




        
            
            
        
    
    
        
            Có một Marilyn Monroe rất khác
        
        
            
                15:30 17/10/2022
                15:30
                17/10/2022
            

            
            
                Xuất bản
            
            

            
            
                Sách hay
            
            

            
        
        
            
            
            0
            
            
        
        Virginia Woolf đã nói rằng một người phụ nữ muốn tự chủ cần phải có tiền và một căn phòng của riêng mình. Marilyn Monroe trong thời hoàng kim cũng đã có được chốn ấy.
        
    




        
            
            
        
    
    
        
            Lý do Tôn Ngộ Không thường ăn vận quần áo có tấm da cọp
        
        
            
                16:32 20/9/2022
                16:32
                20/9/2022
            

            
            
                Xuất bản
            
            

            
            
                Sách hay
            
            

            
        
        
            
            
            0
            
            
        
        Đã quy y Phật, đi thỉnh kinh mà Tề Thiên còn muốn chơi hàng độc thời trang ư? Thật ra đây là một hình ảnh mang tính ẩn dụ.
        
    





    
    
    
    
    Xem thêm

            

            

            
            
            
            

            
                
                    Nổi bật 48 giờ
                
                
                
                    
                        
                    
                
                
                    
                        Giải trí
                    
                    
                        Thế khó của Trấn Thành
                    
                
                Giới trong nghề nhận định &quot;Bố già&quot; đã đạt được doanh thu &quot;vô tiền khoáng hậu&quot; với hơn 400 tỷ đồng. Dự án phim Tết 2023 của Trấn Thành không dễ vượt qua con số này.
                23:04 CN, 06/11
            
                
                    
                        
                    
                
                
                    
                        Giải trí
                    
                    
                        Nghệ sĩ Trung Quốc đang bị tình dục hóa quá mức khi mặc gợi cảm
                    
                
                &quot;Phái yếu mặc gợi cảm, trang điểm đẹp chỉ vì muốn thể hiện cá tính, sự tự tin chứ không phải đang khiêu gợi đàn ông&quot;, Tống Vũ Kỳ nêu quan điểm.
                11:06 hôm qua
            
                
                    
                        
                    
                
                
                    
                        Giải trí
                    
                    
                        ‘Virus cuồng loạn’ - bộ phim cẩu thả của điện ảnh Việt
                    
                
                Dự án điện ảnh kinh dị đầu tay của đạo diễn trẻ Nhất Duy gây thất vọng vì kịch bản chất lượng thấp cùng phong cách làm phim ngô nghê, thiếu tôn trọng người xem.
                11:40 CN, 06/11
            
                
                    
                        
                    
                
                
                    
                        Giải trí
                    
                    
                        Người yêu cũ khóc nức nở khi Aaron Carter qua đời ở tuổi 35
                    
                
                Melanie Martin bật khóc trước nhà riêng của Aaron Carter sau khi anh qua đời. &quot;Hoàng tử nhạc pop&quot; mất ở tuổi 35 trong sự thương tiếc của bạn bè, đồng nghiệp.
                03:37 CN, 06/11
            
                
                    
                        
                    
                
                
                    
                        Giải trí
                    
                    
                        Selena Gomez bị chỉ trích vô ơn với người cho thận
                    
                
                Tình cảm giữa Selena Gomez và Francia Raisa - người đã hiến thận cho cô - rạn nứt sau khi nữ ca sĩ khẳng định chỉ có Taylor Swift là bạn thân trong ngành giải trí.
                15:05 hôm qua
            
            

            
            Quảng cáo của Adtima
            
        
        
    


</value>
      <webElementGuid>c50b1fa4-201e-41e2-b3e2-e66fa0ad8c09</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-category&quot;)/div[@class=&quot;page-wrapper&quot;]</value>
      <webElementGuid>d17aa001-ea19-4ad1-8c1e-81e2831e0be9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='page-category']/div[3]</value>
      <webElementGuid>1162904e-d5a5-4b4b-92c4-9e66374f7f9c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Xe máy'])[1]/following::div[3]</value>
      <webElementGuid>da143713-743c-4f9d-be24-0c84fb6564dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Đánh giá'])[1]/following::div[3]</value>
      <webElementGuid>89939955-03a6-4c80-826f-75cccb424e84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]</value>
      <webElementGuid>4d9181f4-6034-42b1-8437-789a6ec7c8bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;
    
    
    
        Giải trí
    
    
    
        






    Sao




    Âm nhạc




    Phim ảnh




    Thời trang




    
    


    
     

    
        
            
                
                
                    



        
            
            
        
    
    
        
            Quản lý: &quot; , &quot;'&quot; , &quot;Ti Ti không thể có số tiền lớn như trong hình ở sòng bài&quot; , &quot;'&quot; , &quot;
        
        
            
                4 giờ trước
                06:16
                8/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Quản lý xác nhận Ti Ti xuất hiện ở sòng bài Campuchia hồi tháng 7 nhưng anh không biết chơi, chỉ ngồi trông hộ bạn và cũng không có nhiều tiền như vậy.
        
    





                
                
                
                
                    



        
            
            
        
    
    
        
            Tình bạn giữa Selena Gomez và người cho thận trước khi rạn nứt
        
        
            
                39 phút trước
                09:45
                8/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Trả lời phỏng vấn mới nhất, Selena Gomez nói chỉ có Taylor Swift là bạn thân trong ngành, hoàn toàn không đề cập Francia Raisa - nữ diễn viên đã hiến cho cô quả thận năm 2017.
        
    




        
            
            
        
    
    
        
            Hiện trường nơi Aaron Carter qua đời
        
        
            
                1 giờ trước
                09:09
                8/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Nguyên nhân cái chết của Aaron Carter chưa được công bố, song cảnh sát đã phát hiện lon khí nén và thuốc kê đơn trong phòng tắm, phòng ngủ của nam ca sĩ.
        
    





                
                
            
            
            
            
                



        
            
            
        
    
    
        
            Pique hôn bạn gái sau trận đấu cuối cùng
        
        
            
                1 giờ trước
                09:21
                8/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Pique vừa chơi trận đấu cuối cùng tại Camp Nou với tư cách là cầu thủ của Barca. Sau khi bước lên khán đài, anh ôm hôn bạn gái.
        
    




        
            
            
        
    
    
        
            Chân Tử Đan gây bức xúc
        
        
            
                2 giờ trước
                08:48
                8/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Tác phẩm &quot;Giải cứu&quot; của Chân Tử Đan thất bại nặng nề về doanh thu lẫn chất lượng. Phản ứng dửng dưng của anh trên cương vị diễn viên chính và giám đốc sản xuất gây bức xúc.
        
    




        
            
            
        
    
    
        
            Trang Tư Mẫn ly hôn chồng doanh nhân sau 2 năm cưới
        
        
            
                2 giờ trước
                08:40
                8/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            
            
        
        Vợ chồng nữ diễn viên rạn nứt vì vấn đề nơi ở. Trang Tư Mẫn cho biết không yêu cầu doanh nhân Đài Loan chia tài sản hay trợ cấp sau ly hôn.
        
    




        
            
            
        
    
    
        
            BlackPink gây tranh cãi vì liên tục mặc đồ hở hang
        
        
            
                4 giờ trước
                06:23
                8/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            
            
        
        Khán giả đang chỉ trích việc các thành viên BlackPink thời gian gần đây thường xuyên mặc đồ sexy quá mức, đặc biệt trong đêm nhạc của nhóm.
        
    





            
            
        
    


    
    
    
    
    
    
    
    
    
    

    
    

    
        MỚI NHẤT
    
    

        
            



        
            
            
        
    
    
        
            Cha Quan Hiểu Đồng bức xúc vì tin đồn đòi quà đính hôn 100 triệu NDT
        
        
            
                10 giờ trước
                00:04
                8/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            
            
        
        Tin tức Quan Hiểu Đồng - Lộc Hàm đã đăng ký kết hôn gây xôn xao dư luận Trung Quốc. Cha nữ diễn viên lên tiếng phủ nhận và nói tin đồn quá cường điệu và thất thiệt.
        
    




        
            
            
        
    
    
        
            Ca sĩ Ti Ti (HKT) lên tiếng thông tin đánh bài tại sòng bạc Campuchia
        
        
            
                12 giờ trước
                22:16
                7/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            27
            
        
        Nam ca sĩ Ti Ti xác nhận hình ảnh thanh niên ngồi ở sòng bạc Campuchia là mình. Tuy nhiên, anh khẳng định bản thân không đánh bạc mà chỉ &quot;ngồi giữ tiền giùm bạn&quot;.
        
    




        
            
            
        
    
    
        
            Selena Gomez bị chỉ trích vô ơn với người cho thận
        
        
            
                12 giờ trước
                22:05
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            1
            
        
        Tình cảm giữa Selena Gomez và Francia Raisa - người đã hiến thận cho cô - rạn nứt sau khi nữ ca sĩ khẳng định chỉ có Taylor Swift là bạn thân trong ngành giải trí.
        
    




        
            
            
        
    
    
        
            Nhiều nghệ sĩ Hàn bị yêu cầu rời khỏi ngành giải trí
        
        
            
                13 giờ trước
                21:23
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            2
            
        
        MC Ding Dong, Lizzy và Yoon Je Moon đang bị truyền thông Hàn Quốc chỉ trích vì trở lại ngành giải trí. Họ từng lái xe trong tình trạng say rượu.
        
    




        
            
            
        
    
    
        
            CEO nữ từ chức sau khi bạo hành nhóm nhạc nam
        
        
            
                14 giờ trước
                20:48
                7/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            
            
        
        Công ty thông báo nữ CEO đã nghỉ việc nhưng người hâm mộ vẫn tỏ ra nghi hoặc và cho rằng đây chỉ là động thái trấn an dư luận.
        
    




        
            
            
        
    
    
        
            Điều cấm kỵ khi phối đồ đi xem World Cup 2022
        
        
            
                14 giờ trước
                20:22
                7/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            
            
        
        Khi xếp hành lý để chuẩn bị đi xem World Cup, bạn cần chú ý các loại trang phục được mặc để nghĩ cách phối phù hợp.
        
    




        
            
            
        
    
    
        
            Miss Universe 2021 bị soi vóc dáng đẫy đà
        
        
            
                14 giờ trước
                19:59
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            17
            
        
        Đương kim Miss Universe Harnaaz Sandhu bị soi ngoại hình khi xuất hiện cùng dàn người đẹp Hoa hậu Hoàn vũ.
        
    




        
            
            
        
    
    
        
            Trùm giải trí Tăng Chí Vỹ nổi giận tại trường quay vì bị trêu chọc
        
        
            
                15 giờ trước
                19:31
                7/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            4
            
        
        Tăng Chí Vỹ bực tức với hành động đùa giỡn không đúng lúc của Lâm Mẫn Thông trong quá trình quay show. Ông yêu cầu dừng ghi hình để đồng nghiệp kiểm điểm hành vi.
        
    




        
            
            
        
    
    
        
            &quot; , &quot;'&quot; , &quot;Chu Bá Thông&quot; , &quot;'&quot; , &quot; Tần Hoàng giảm 30 kg để giữ tính mạng
        
        
            
                15 giờ trước
                19:00
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            22
            
        
        Nam diễn viên gạo cội của TVB mắc nhiều bệnh vì nặng đến 127 kg. Thời gian qua, ông tìm mọi cách giảm cân để cải thiện sức khỏe.
        
    




        
            
            
        
    
    
        
            Nghệ sĩ Trung Quốc đang bị tình dục hóa quá mức khi mặc gợi cảm
        
        
            
                16 giờ trước
                18:06
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            2
            
        
        &quot;Phái yếu mặc gợi cảm, trang điểm đẹp chỉ vì muốn thể hiện cá tính, sự tự tin chứ không phải đang khiêu gợi đàn ông&quot;, Tống Vũ Kỳ nêu quan điểm.
        
    




        
            
            
        
    
    
        
            Phụ nữ mang thai có thể thi Hoa hậu Hoàn vũ Philippines
        
        
            
                17 giờ trước
                16:58
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Cuộc thi Hoa hậu Hoàn vũ Philippines 2023 thay đổi tiêu chí so với những mùa trước, không giới hạn chiều cao cũng như tình trạng hôn nhân.
        
    




        
            
            
        
    
    
        
            Kim Kardashian, Selena Gomez và dàn sao mặc đẹp nhất tuần
        
        
            
                19 giờ trước
                15:45
                7/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            
            
        
        Các mẫu váy áo cắt xẻ, bó sát đang phủ sóng trên thảm đỏ. Thiết kế gợi cảm giúp nhiều sao nữ được khen ngợi.
        
    




        
            
            
        
    
    
        
            Người rao bán mũ của Jung Kook (BTS) thú tội
        
        
            
                19 giờ trước
                15:43
                7/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            
            
        
        Trước phản ứng gay gắt của cộng đồng mạng, cựu viên chức Bộ Ngoại giao Hàn Quốc đã gỡ bỏ thông tin rao bán mũ của Jung Kook và tới sở cảnh sát để thú tội.
        
    




        
            
            
        
    
    
        
            Loạt mốt thời trang gây tranh luận của nghệ sĩ
        
        
            
                21 giờ trước
                13:19
                7/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            
            
        
        Năm nay, nhiều mốt thời trang độc đáo được ưa chuộng. Song, nhiều nghệ sĩ cũng gây tranh cãi khi diện đồ xuyên thấu, lộ nội y.
        
    




        
            
            
        
    
    
        
            Gigi Hadid xóa Twitter vì Elon Musk nắm quyền
        
        
            
                22 giờ trước
                12:13
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Sao Hollywood
            
            

            
        
        
            
            
            0
            1
            
        
        Siêu mẫu Gigi Hadid tuyên bố xóa tài khoản Twitter của mình sau khi Elon Musk ngồi lên ghế chủ tịch tập đoàn.
        
    




        
            
            
        
    
    
        
            Lý do Tần Lam chưa kết hôn ở tuổi 43
        
        
            
                24 giờ trước
                10:25
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            12
            
        
        Tần Lam cho biết không mặn mà với chuyện hẹn hò hay hôn nhân. Cô và đối tượng khác giới có xu hướng trở thành bạn tốt của nhau sau một thời gian tìm hiểu.
        
    




        
            
            
        
    
    
        
            &quot; , &quot;'&quot; , &quot;Kẻ độc hành&quot; , &quot;'&quot; , &quot; của Huỳnh Lập - giống Châu Tinh Trì nhưng cũ, kỹ xảo kém
        
        
            
                09:34 7/11/2022
                09:34
                7/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            84
            
        
        Huỳnh Lập tiếp tục sản xuất kiêm đóng chính trong phần tiền truyện của &quot;Pháp sư mù&quot; và &quot;Ai chết giơ tay&quot;. Nam nghệ sĩ áp dụng lại lối pha trò cũ, thiếu sự mới mẻ ở kịch bản.
        
    




        
            
            
        
    
    
        
            Anh trai bật khóc trên sân khấu sau cái chết của Aaron Carter
        
        
            
                09:11 7/11/2022
                09:11
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            8
            
        
        Nick Carter đau buồn khi em trai qua đời. Trước khi Aaron Carter mất, mối quan hệ giữa hai nam ca sĩ không tốt đẹp, thậm chí từng cạch mặt nhau.
        
    




        
            
            
        
    
    
        
            Nữ người mẫu thuộc giới thượng lưu ở Dubai
        
        
            
                08:33 7/11/2022
                08:33
                7/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            
            
        
        LJ Loujain Adada tận hưởng cuộc sống xa hoa với những chuyến du lịch xa xỉ, loạt đồ hiệu đắt đỏ. Cô có ngoại hình ấn tượng cùng gu thời trang gợi cảm.
        
    




        
            
            
        
    
    
        
            Phim của The Rock tiếp tục dẫn đầu phòng vé
        
        
            
                08:27 7/11/2022
                08:27
                7/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            4
            
        
        &quot;Black Adam&quot; duy trì ngôi vương phòng vé nội địa trong tuần thứ ba liên tiếp. Bom tấn do The Rock đóng chính được dự đoán vượt qua thành tích của &quot;Shazam&quot; (2019).
        
    




        
            
            
        
    
    
        
            CEO Phạm Kim Dung: Nam Em từng bị lừa gạt, đòi tiền mua giải
        
        
            
                07:59 7/11/2022
                07:59
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            22
            
        
        Bà Phạm Kim Dung - Chủ tịch công ty Sen Vàng - chia sẻ Nam Em từng rơi vào trường hợp bị kẻ xấu lừa gạt, đặt vấn đề mua giải hoa khôi.
        
    




        
            
            
        
    
    
        
            Chú rể Việt vẫn an toàn khi chọn trang phục cưới
        
        
            
                07:16 7/11/2022
                07:16
                7/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            337
            
        
        Vì ít mặc suit hay vest, nhiều người thường ngại phá vỡ công thức truyền thống. Stylist Khúc Mạnh Quân có nhiều lời khuyên cho nam giới Việt khi chọn đồ cưới.
        
    




        
            
            
        
    
    
        
            Thế khó của Trấn Thành
        
        
            
                06:04 7/11/2022
                06:04
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            6
            
        
        Giới trong nghề nhận định &quot;Bố già&quot; đã đạt được doanh thu &quot;vô tiền khoáng hậu&quot; với hơn 400 tỷ đồng. Dự án phim Tết 2023 của Trấn Thành không dễ vượt qua con số này.
        
    




        
            
            
        
    
    
        
            Sức khỏe hiện tại của &quot; , &quot;'&quot; , &quot;Khương Tử Nha&quot; , &quot;'&quot; , &quot; Dư Tử Minh
        
        
            
                22:44 6/11/2022
                22:44
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            20
            
        
        Dư Tử Minh là diễn viên gạo cội của TVB từng tham gia nhiều tác phẩm kinh điển. Sức khỏe của ông yếu đi sau cơn đột quỵ hồi đầu năm.
        
    




        
            
            
        
    
    
        
            Nadech Kugimiya và Yaya Urassaya lên kế hoạch kết hôn sau 12 năm yêu
        
        
            
                21:54 6/11/2022
                21:54
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            1
            
        
        Nadech Kugimiya tiết lộ đang chuẩn bị lễ cưới với Yaya Urassaya. Họ là ngôi sao hàng đầu và có thu nhập cao tại Thái Lan.
        
    




        
            
            
        
    
    
        
            Amee, Liên Bỉnh Phát dự lễ cưới Masew
        
        
            
                20:08 6/11/2022
                20:08
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            85
            
        
        Masew tổ chức lễ cưới vào tối 6/11 với sự tham gia của nhiều đồng nghiệp thân thiết như Amee, B Ray, Liên Bỉnh Phát, Đạt G, Quân A.P...
        
    




        
            
            
        
    
    
        
            Trần Phi Vũ chứng tỏ không chỉ mang danh &quot; , &quot;'&quot; , &quot;con trai Trần Khải Ca&quot; , &quot;'&quot; , &quot;
        
        
            
                19:21 6/11/2022
                19:21
                6/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            
            
        
        Trần Phi Vũ đang được mệnh danh là &quot;bạn trai trong mơ&quot; nhờ vai diễn thiên tài Lý Tuấn trong phim ngôn tình &quot;Chiếc bật lửa và váy công chúa&quot;.
        
    




        
            
            
        
    
    
        
            ‘Virus cuồng loạn’ - bộ phim cẩu thả của điện ảnh Việt
        
        
            
                18:40 6/11/2022
                18:40
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            43
            
        
        Dự án điện ảnh kinh dị đầu tay của đạo diễn trẻ Nhất Duy gây thất vọng vì kịch bản chất lượng thấp cùng phong cách làm phim ngô nghê, thiếu tôn trọng người xem.
        
    




        
            
            
        
    
    
        
            Tranh luận việc nữ ca sĩ 14 tuổi biểu diễn vũ đạo gợi cảm
        
        
            
                15:09 6/11/2022
                15:09
                6/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            1
            
        
        CLASS:y có hai thành viên sinh năm 2008. Do đó, việc nhóm chuyển sang phong cách trưởng thành và có nhiều động tác gợi cảm khiến khán giả tranh luận.
        
    




        
            
            
        
    
    
        
            &quot; , &quot;'&quot; , &quot;Bông hồng lai&quot; , &quot;'&quot; , &quot; Patricia Good và đại gia Thái Lan chuẩn bị cho lễ cưới
        
        
            
                14:20 6/11/2022
                14:20
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            9
            
        
        Patricia Good và doanh nhân giàu có Note Vises đính hôn hồi tháng 6. Họ vừa thực hiện các nghi thức dâng hoa và nhận nước thánh tại chùa.
        
    




        
            
            
        
    
    
        
            Hàng ghế đầu Tuần lễ thời trang có còn mất giá vì TikToker tai tiếng
        
        
            
                12:26 6/11/2022
                12:26
                6/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            8
            
        
        Khách mời tại sự kiện thời trang phụ thuộc vào nhiều nguồn. Bên cạnh đó, ban tổ chức Tuần lễ thời trang khuyến khích không mang những điều quá dị hợm đến sự kiện.
        
    




        
            
            
        
    
    
        
            Ngành giải trí Nhật Bản chấn động vì nam ca sĩ qua đời ở tuổi 19
        
        
            
                11:37 6/11/2022
                11:37
                6/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            12
            
        
        Nikkan Sports đưa tin nam ca sĩ kiêm diễn viên Yoshi bị tai nạn vào sáng 5/11. Vụ việc khiến anh bị thương nặng và qua đời sau đó.
        
    




        
            
            
        
    
    
        
            Aaron Carter - từ &quot; , &quot;'&quot; , &quot;hoàng tử trong mơ&quot; , &quot;'&quot; , &quot; đến cái chết ở tuổi 35
        
        
            
                11:02 6/11/2022
                11:02
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Sao Hollywood
            
            

            
        
        
            
            
            0
            43
            
        
        Trở thành ngôi sao toàn cầu từ khi còn rất nhỏ, sự nghiệp của Aaron Carter lên &quot;như diều gặp gió&quot;. Tuy nhiên, mặt tối hào quang và bi kịch gia đình khiến anh tụt dốc không phanh.
        
    




        
            
            
        
    
    
        
            Hôn lễ của diễn viên &quot; , &quot;'&quot; , &quot;Tình dục là chuyện nhỏ&quot; , &quot;'&quot; , &quot; và vợ kém 24 tuổi
        
        
            
                10:26 6/11/2022
                10:26
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Hôn lễ của nam diễn viên Choi Seong Guk diễn ra tối 5/11 tại Jongno-gu. Anh và bạn gái quen nhau một năm trước khi về chung một nhà.
        
    




        
            
            
        
    
    
        
            &quot; , &quot;'&quot; , &quot;Trương Phi&quot; , &quot;'&quot; , &quot; chưa biết &quot; , &quot;'&quot; , &quot;Quan Vũ&quot; , &quot;'&quot; , &quot; qua đời
        
        
            
                10:15 6/11/2022
                10:15
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Trong &quot;Tam quốc diễn nghĩa&quot;, khi Quan Vũ qua đời, Trương Phi khóc tới ngất. Song, khi &quot;Quan Vũ&quot; Lục Thụ Minh ra đi, người thân không dám báo &quot;Trương Phi&quot; Lý Tĩnh Phi.
        
    




        
            
            
        
    
    
        
            Angelababy khủng hoảng phiên vị
        
        
            
                09:30 6/11/2022
                09:30
                6/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            
            
        
        Angelababy lép vế trước Nhậm Gia Luân trong phim truyền hình mới &quot;Mộ sắc tâm ước&quot;. Điều này khiến người hâm mộ của cô thất vọng.
        
    




        
            
            
        
    
    
        
            Những ngày cuối đời của Aaron Carter
        
        
            
                09:11 6/11/2022
                09:11
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            46
            
        
        Một tháng trước khi mất, Aaron Carter rao bán căn nhà riêng để &quot;bắt đầu chương mới của cuộc đời&quot;. Mối quan hệ của anh và hôn thê cũng trở nên tồi tệ.
        
    




        
            
            
        
    
    
        
            Người đẹp Trà Vinh cao 1,8 m là tân Hoa khôi Nam Bộ 2022
        
        
            
                09:09 6/11/2022
                09:09
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            4
            
        
        Đêm chung kết cuộc thi Hoa khôi Nam Bộ 2022 được tổ chức tại TP Cần Thơ vừa kết thúc tối 5/11. Kết quả thí sinh Lê Thị Kiều Nhung (Trà Vinh) đoạt vương miện hoa khôi.
        
    




        
            
            
        
    
    
        
            Phim đồng tính và mặt tối &quot; , &quot;'&quot; , &quot;queerbaiting’
        
        
            
                08:31 6/11/2022
                08:31
                6/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            7
            
        
        Từng là một địa hạt cực kỳ nhạy cảm, câu chuyện về cộng đồng LGBTQ+ dần có những bước tiếp cận tiến bộ với khán giả đại chúng.
        
    




        
            
            
        
    
    
        
            Son Heung-min mặc đẹp
        
        
            
                08:09 6/11/2022
                08:09
                6/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            7
            
        
        Không phải ngôi sao giải trí nhưng gu ăn mặc của Son Heung-min chẳng hề kém cạnh. Bên ngoài sân cỏ, anh chính là tín đồ thời trang.
        
    




        
            
            
        
    
    
        
            Aaron Carter qua đời
        
        
            
                08:02 6/11/2022
                08:02
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            76
            
        
        Ca sĩ Aaron Carter qua đời đột ngột tại nhà riêng ở Lancaster, California, Mỹ. Nguyên nhân cái chết của anh vẫn chưa được xác định.
        
    




        
            
            
        
    
    
        
            Tăng Thanh Hà và Louis Nguyễn kỷ niệm 10 năm ngày cưới
        
        
            
                08:02 6/11/2022
                08:02
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            16
            
        
        Vợ chồng Tăng Thanh Hà tổ chức bữa tiệc ấm cúng bên người thân, bạn bè để kỷ niệm 10 năm ngày về chung một nhà.
        
    






            
            
                Xem thêm
            
            
        

        
        
            

            
            
    
    
        
        SIGNATURE SERIES
    
    
    
    



        
            
            10:02
            
            
        
    
    
        
            Ca sĩ Bích Phương: &quot; , &quot;'&quot; , &quot;Bản chất tôi là người lười biếng&quot; , &quot;'&quot; , &quot;
        
        
            
                06:08 6/12/2021
                06:08
                6/12/2021
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Bích Phương cho biết cô vốn có tính lười, nên trong một năm đầu tiên dịch bệnh diễn ra, nữ ca sĩ chỉ nằm trong nhà và không làm bất cứ việc gì.
        
    




        
            
            12:28
            
            
        
    
    
        
            Erik: &quot; , &quot;'&quot; , &quot;Tham gia 10 cuộc thi, lần đầu tôi giành quán quân&quot; , &quot;'&quot; , &quot;
        
        
            
                07:33 5/12/2021
                07:33
                5/12/2021
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            
            
        
        Erik vừa giành chiến thắng ở chương trình The Heroes. Nam ca sĩ cho biết anh hạnh phúc khi cuối cùng đã nhận giải quán quân sau nhiều cuộc thi.
        
    




        
            
            14:54
            
            
        
    
    
        
            Ca sĩ Mlee: &quot; , &quot;'&quot; , &quot;Nếu bạn trai đi quá giới hạn, tôi sẽ chia tay&quot; , &quot;'&quot; , &quot;
        
        
            
                06:20 19/9/2021
                06:20
                19/9/2021
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Mlee cho biết cô yêu hết mình nhưng cũng dứt khoát chia tay nếu bạn trai đi quá giới hạn. Nữ ca sĩ cho biết hiện cô độc thân để dồn thời gian cho công việc.
        
    





    
    
    
    
    Xem thêm

            
            
    
    
        
        Sách Nghệ thuật - Giải trí
    
    
    
    



        
            
            
        
    
    
        
            Bà trùm nội y từng đi giao báo kiếm tiền năm 10 tuổi
        
        
            
                20:18 29/10/2022
                20:18
                29/10/2022
            

            
            
                Xuất bản
            
            

            
            
                Sách hay
            
            

            
        
        
            
            
            0
            
            
        
        “Tôi thuyết phục quầy báo nằm trên cùng con phố cho tôi đi giao báo. Lượng báo phải giao rất nhiều, nhưng tôi rất quyết tâm”, Michelle Mone kể trong cuốn tự truyện.
        
    




        
            
            
        
    
    
        
            Có một Marilyn Monroe rất khác
        
        
            
                15:30 17/10/2022
                15:30
                17/10/2022
            

            
            
                Xuất bản
            
            

            
            
                Sách hay
            
            

            
        
        
            
            
            0
            
            
        
        Virginia Woolf đã nói rằng một người phụ nữ muốn tự chủ cần phải có tiền và một căn phòng của riêng mình. Marilyn Monroe trong thời hoàng kim cũng đã có được chốn ấy.
        
    




        
            
            
        
    
    
        
            Lý do Tôn Ngộ Không thường ăn vận quần áo có tấm da cọp
        
        
            
                16:32 20/9/2022
                16:32
                20/9/2022
            

            
            
                Xuất bản
            
            

            
            
                Sách hay
            
            

            
        
        
            
            
            0
            
            
        
        Đã quy y Phật, đi thỉnh kinh mà Tề Thiên còn muốn chơi hàng độc thời trang ư? Thật ra đây là một hình ảnh mang tính ẩn dụ.
        
    





    
    
    
    
    Xem thêm

            

            

            
            
            
            

            
                
                    Nổi bật 48 giờ
                
                
                
                    
                        
                    
                
                
                    
                        Giải trí
                    
                    
                        Thế khó của Trấn Thành
                    
                
                Giới trong nghề nhận định &quot;Bố già&quot; đã đạt được doanh thu &quot;vô tiền khoáng hậu&quot; với hơn 400 tỷ đồng. Dự án phim Tết 2023 của Trấn Thành không dễ vượt qua con số này.
                23:04 CN, 06/11
            
                
                    
                        
                    
                
                
                    
                        Giải trí
                    
                    
                        Nghệ sĩ Trung Quốc đang bị tình dục hóa quá mức khi mặc gợi cảm
                    
                
                &quot;Phái yếu mặc gợi cảm, trang điểm đẹp chỉ vì muốn thể hiện cá tính, sự tự tin chứ không phải đang khiêu gợi đàn ông&quot;, Tống Vũ Kỳ nêu quan điểm.
                11:06 hôm qua
            
                
                    
                        
                    
                
                
                    
                        Giải trí
                    
                    
                        ‘Virus cuồng loạn’ - bộ phim cẩu thả của điện ảnh Việt
                    
                
                Dự án điện ảnh kinh dị đầu tay của đạo diễn trẻ Nhất Duy gây thất vọng vì kịch bản chất lượng thấp cùng phong cách làm phim ngô nghê, thiếu tôn trọng người xem.
                11:40 CN, 06/11
            
                
                    
                        
                    
                
                
                    
                        Giải trí
                    
                    
                        Người yêu cũ khóc nức nở khi Aaron Carter qua đời ở tuổi 35
                    
                
                Melanie Martin bật khóc trước nhà riêng của Aaron Carter sau khi anh qua đời. &quot;Hoàng tử nhạc pop&quot; mất ở tuổi 35 trong sự thương tiếc của bạn bè, đồng nghiệp.
                03:37 CN, 06/11
            
                
                    
                        
                    
                
                
                    
                        Giải trí
                    
                    
                        Selena Gomez bị chỉ trích vô ơn với người cho thận
                    
                
                Tình cảm giữa Selena Gomez và Francia Raisa - người đã hiến thận cho cô - rạn nứt sau khi nữ ca sĩ khẳng định chỉ có Taylor Swift là bạn thân trong ngành giải trí.
                15:05 hôm qua
            
            

            
            Quảng cáo của Adtima
            
        
        
    


&quot;) or . = concat(&quot;
    
    
    
        Giải trí
    
    
    
        






    Sao




    Âm nhạc




    Phim ảnh




    Thời trang




    
    


    
     

    
        
            
                
                
                    



        
            
            
        
    
    
        
            Quản lý: &quot; , &quot;'&quot; , &quot;Ti Ti không thể có số tiền lớn như trong hình ở sòng bài&quot; , &quot;'&quot; , &quot;
        
        
            
                4 giờ trước
                06:16
                8/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Quản lý xác nhận Ti Ti xuất hiện ở sòng bài Campuchia hồi tháng 7 nhưng anh không biết chơi, chỉ ngồi trông hộ bạn và cũng không có nhiều tiền như vậy.
        
    





                
                
                
                
                    



        
            
            
        
    
    
        
            Tình bạn giữa Selena Gomez và người cho thận trước khi rạn nứt
        
        
            
                39 phút trước
                09:45
                8/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Trả lời phỏng vấn mới nhất, Selena Gomez nói chỉ có Taylor Swift là bạn thân trong ngành, hoàn toàn không đề cập Francia Raisa - nữ diễn viên đã hiến cho cô quả thận năm 2017.
        
    




        
            
            
        
    
    
        
            Hiện trường nơi Aaron Carter qua đời
        
        
            
                1 giờ trước
                09:09
                8/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Nguyên nhân cái chết của Aaron Carter chưa được công bố, song cảnh sát đã phát hiện lon khí nén và thuốc kê đơn trong phòng tắm, phòng ngủ của nam ca sĩ.
        
    





                
                
            
            
            
            
                



        
            
            
        
    
    
        
            Pique hôn bạn gái sau trận đấu cuối cùng
        
        
            
                1 giờ trước
                09:21
                8/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Pique vừa chơi trận đấu cuối cùng tại Camp Nou với tư cách là cầu thủ của Barca. Sau khi bước lên khán đài, anh ôm hôn bạn gái.
        
    




        
            
            
        
    
    
        
            Chân Tử Đan gây bức xúc
        
        
            
                2 giờ trước
                08:48
                8/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Tác phẩm &quot;Giải cứu&quot; của Chân Tử Đan thất bại nặng nề về doanh thu lẫn chất lượng. Phản ứng dửng dưng của anh trên cương vị diễn viên chính và giám đốc sản xuất gây bức xúc.
        
    




        
            
            
        
    
    
        
            Trang Tư Mẫn ly hôn chồng doanh nhân sau 2 năm cưới
        
        
            
                2 giờ trước
                08:40
                8/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            
            
        
        Vợ chồng nữ diễn viên rạn nứt vì vấn đề nơi ở. Trang Tư Mẫn cho biết không yêu cầu doanh nhân Đài Loan chia tài sản hay trợ cấp sau ly hôn.
        
    




        
            
            
        
    
    
        
            BlackPink gây tranh cãi vì liên tục mặc đồ hở hang
        
        
            
                4 giờ trước
                06:23
                8/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            
            
        
        Khán giả đang chỉ trích việc các thành viên BlackPink thời gian gần đây thường xuyên mặc đồ sexy quá mức, đặc biệt trong đêm nhạc của nhóm.
        
    





            
            
        
    


    
    
    
    
    
    
    
    
    
    

    
    

    
        MỚI NHẤT
    
    

        
            



        
            
            
        
    
    
        
            Cha Quan Hiểu Đồng bức xúc vì tin đồn đòi quà đính hôn 100 triệu NDT
        
        
            
                10 giờ trước
                00:04
                8/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            
            
        
        Tin tức Quan Hiểu Đồng - Lộc Hàm đã đăng ký kết hôn gây xôn xao dư luận Trung Quốc. Cha nữ diễn viên lên tiếng phủ nhận và nói tin đồn quá cường điệu và thất thiệt.
        
    




        
            
            
        
    
    
        
            Ca sĩ Ti Ti (HKT) lên tiếng thông tin đánh bài tại sòng bạc Campuchia
        
        
            
                12 giờ trước
                22:16
                7/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            27
            
        
        Nam ca sĩ Ti Ti xác nhận hình ảnh thanh niên ngồi ở sòng bạc Campuchia là mình. Tuy nhiên, anh khẳng định bản thân không đánh bạc mà chỉ &quot;ngồi giữ tiền giùm bạn&quot;.
        
    




        
            
            
        
    
    
        
            Selena Gomez bị chỉ trích vô ơn với người cho thận
        
        
            
                12 giờ trước
                22:05
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            1
            
        
        Tình cảm giữa Selena Gomez và Francia Raisa - người đã hiến thận cho cô - rạn nứt sau khi nữ ca sĩ khẳng định chỉ có Taylor Swift là bạn thân trong ngành giải trí.
        
    




        
            
            
        
    
    
        
            Nhiều nghệ sĩ Hàn bị yêu cầu rời khỏi ngành giải trí
        
        
            
                13 giờ trước
                21:23
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            2
            
        
        MC Ding Dong, Lizzy và Yoon Je Moon đang bị truyền thông Hàn Quốc chỉ trích vì trở lại ngành giải trí. Họ từng lái xe trong tình trạng say rượu.
        
    




        
            
            
        
    
    
        
            CEO nữ từ chức sau khi bạo hành nhóm nhạc nam
        
        
            
                14 giờ trước
                20:48
                7/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            
            
        
        Công ty thông báo nữ CEO đã nghỉ việc nhưng người hâm mộ vẫn tỏ ra nghi hoặc và cho rằng đây chỉ là động thái trấn an dư luận.
        
    




        
            
            
        
    
    
        
            Điều cấm kỵ khi phối đồ đi xem World Cup 2022
        
        
            
                14 giờ trước
                20:22
                7/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            
            
        
        Khi xếp hành lý để chuẩn bị đi xem World Cup, bạn cần chú ý các loại trang phục được mặc để nghĩ cách phối phù hợp.
        
    




        
            
            
        
    
    
        
            Miss Universe 2021 bị soi vóc dáng đẫy đà
        
        
            
                14 giờ trước
                19:59
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            17
            
        
        Đương kim Miss Universe Harnaaz Sandhu bị soi ngoại hình khi xuất hiện cùng dàn người đẹp Hoa hậu Hoàn vũ.
        
    




        
            
            
        
    
    
        
            Trùm giải trí Tăng Chí Vỹ nổi giận tại trường quay vì bị trêu chọc
        
        
            
                15 giờ trước
                19:31
                7/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            4
            
        
        Tăng Chí Vỹ bực tức với hành động đùa giỡn không đúng lúc của Lâm Mẫn Thông trong quá trình quay show. Ông yêu cầu dừng ghi hình để đồng nghiệp kiểm điểm hành vi.
        
    




        
            
            
        
    
    
        
            &quot; , &quot;'&quot; , &quot;Chu Bá Thông&quot; , &quot;'&quot; , &quot; Tần Hoàng giảm 30 kg để giữ tính mạng
        
        
            
                15 giờ trước
                19:00
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            22
            
        
        Nam diễn viên gạo cội của TVB mắc nhiều bệnh vì nặng đến 127 kg. Thời gian qua, ông tìm mọi cách giảm cân để cải thiện sức khỏe.
        
    




        
            
            
        
    
    
        
            Nghệ sĩ Trung Quốc đang bị tình dục hóa quá mức khi mặc gợi cảm
        
        
            
                16 giờ trước
                18:06
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            2
            
        
        &quot;Phái yếu mặc gợi cảm, trang điểm đẹp chỉ vì muốn thể hiện cá tính, sự tự tin chứ không phải đang khiêu gợi đàn ông&quot;, Tống Vũ Kỳ nêu quan điểm.
        
    




        
            
            
        
    
    
        
            Phụ nữ mang thai có thể thi Hoa hậu Hoàn vũ Philippines
        
        
            
                17 giờ trước
                16:58
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Cuộc thi Hoa hậu Hoàn vũ Philippines 2023 thay đổi tiêu chí so với những mùa trước, không giới hạn chiều cao cũng như tình trạng hôn nhân.
        
    




        
            
            
        
    
    
        
            Kim Kardashian, Selena Gomez và dàn sao mặc đẹp nhất tuần
        
        
            
                19 giờ trước
                15:45
                7/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            
            
        
        Các mẫu váy áo cắt xẻ, bó sát đang phủ sóng trên thảm đỏ. Thiết kế gợi cảm giúp nhiều sao nữ được khen ngợi.
        
    




        
            
            
        
    
    
        
            Người rao bán mũ của Jung Kook (BTS) thú tội
        
        
            
                19 giờ trước
                15:43
                7/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            
            
        
        Trước phản ứng gay gắt của cộng đồng mạng, cựu viên chức Bộ Ngoại giao Hàn Quốc đã gỡ bỏ thông tin rao bán mũ của Jung Kook và tới sở cảnh sát để thú tội.
        
    




        
            
            
        
    
    
        
            Loạt mốt thời trang gây tranh luận của nghệ sĩ
        
        
            
                21 giờ trước
                13:19
                7/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            
            
        
        Năm nay, nhiều mốt thời trang độc đáo được ưa chuộng. Song, nhiều nghệ sĩ cũng gây tranh cãi khi diện đồ xuyên thấu, lộ nội y.
        
    




        
            
            
        
    
    
        
            Gigi Hadid xóa Twitter vì Elon Musk nắm quyền
        
        
            
                22 giờ trước
                12:13
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Sao Hollywood
            
            

            
        
        
            
            
            0
            1
            
        
        Siêu mẫu Gigi Hadid tuyên bố xóa tài khoản Twitter của mình sau khi Elon Musk ngồi lên ghế chủ tịch tập đoàn.
        
    




        
            
            
        
    
    
        
            Lý do Tần Lam chưa kết hôn ở tuổi 43
        
        
            
                24 giờ trước
                10:25
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            12
            
        
        Tần Lam cho biết không mặn mà với chuyện hẹn hò hay hôn nhân. Cô và đối tượng khác giới có xu hướng trở thành bạn tốt của nhau sau một thời gian tìm hiểu.
        
    




        
            
            
        
    
    
        
            &quot; , &quot;'&quot; , &quot;Kẻ độc hành&quot; , &quot;'&quot; , &quot; của Huỳnh Lập - giống Châu Tinh Trì nhưng cũ, kỹ xảo kém
        
        
            
                09:34 7/11/2022
                09:34
                7/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            84
            
        
        Huỳnh Lập tiếp tục sản xuất kiêm đóng chính trong phần tiền truyện của &quot;Pháp sư mù&quot; và &quot;Ai chết giơ tay&quot;. Nam nghệ sĩ áp dụng lại lối pha trò cũ, thiếu sự mới mẻ ở kịch bản.
        
    




        
            
            
        
    
    
        
            Anh trai bật khóc trên sân khấu sau cái chết của Aaron Carter
        
        
            
                09:11 7/11/2022
                09:11
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            8
            
        
        Nick Carter đau buồn khi em trai qua đời. Trước khi Aaron Carter mất, mối quan hệ giữa hai nam ca sĩ không tốt đẹp, thậm chí từng cạch mặt nhau.
        
    




        
            
            
        
    
    
        
            Nữ người mẫu thuộc giới thượng lưu ở Dubai
        
        
            
                08:33 7/11/2022
                08:33
                7/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            
            
        
        LJ Loujain Adada tận hưởng cuộc sống xa hoa với những chuyến du lịch xa xỉ, loạt đồ hiệu đắt đỏ. Cô có ngoại hình ấn tượng cùng gu thời trang gợi cảm.
        
    




        
            
            
        
    
    
        
            Phim của The Rock tiếp tục dẫn đầu phòng vé
        
        
            
                08:27 7/11/2022
                08:27
                7/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            4
            
        
        &quot;Black Adam&quot; duy trì ngôi vương phòng vé nội địa trong tuần thứ ba liên tiếp. Bom tấn do The Rock đóng chính được dự đoán vượt qua thành tích của &quot;Shazam&quot; (2019).
        
    




        
            
            
        
    
    
        
            CEO Phạm Kim Dung: Nam Em từng bị lừa gạt, đòi tiền mua giải
        
        
            
                07:59 7/11/2022
                07:59
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            22
            
        
        Bà Phạm Kim Dung - Chủ tịch công ty Sen Vàng - chia sẻ Nam Em từng rơi vào trường hợp bị kẻ xấu lừa gạt, đặt vấn đề mua giải hoa khôi.
        
    




        
            
            
        
    
    
        
            Chú rể Việt vẫn an toàn khi chọn trang phục cưới
        
        
            
                07:16 7/11/2022
                07:16
                7/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            337
            
        
        Vì ít mặc suit hay vest, nhiều người thường ngại phá vỡ công thức truyền thống. Stylist Khúc Mạnh Quân có nhiều lời khuyên cho nam giới Việt khi chọn đồ cưới.
        
    




        
            
            
        
    
    
        
            Thế khó của Trấn Thành
        
        
            
                06:04 7/11/2022
                06:04
                7/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            6
            
        
        Giới trong nghề nhận định &quot;Bố già&quot; đã đạt được doanh thu &quot;vô tiền khoáng hậu&quot; với hơn 400 tỷ đồng. Dự án phim Tết 2023 của Trấn Thành không dễ vượt qua con số này.
        
    




        
            
            
        
    
    
        
            Sức khỏe hiện tại của &quot; , &quot;'&quot; , &quot;Khương Tử Nha&quot; , &quot;'&quot; , &quot; Dư Tử Minh
        
        
            
                22:44 6/11/2022
                22:44
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            20
            
        
        Dư Tử Minh là diễn viên gạo cội của TVB từng tham gia nhiều tác phẩm kinh điển. Sức khỏe của ông yếu đi sau cơn đột quỵ hồi đầu năm.
        
    




        
            
            
        
    
    
        
            Nadech Kugimiya và Yaya Urassaya lên kế hoạch kết hôn sau 12 năm yêu
        
        
            
                21:54 6/11/2022
                21:54
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            1
            
        
        Nadech Kugimiya tiết lộ đang chuẩn bị lễ cưới với Yaya Urassaya. Họ là ngôi sao hàng đầu và có thu nhập cao tại Thái Lan.
        
    




        
            
            
        
    
    
        
            Amee, Liên Bỉnh Phát dự lễ cưới Masew
        
        
            
                20:08 6/11/2022
                20:08
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            85
            
        
        Masew tổ chức lễ cưới vào tối 6/11 với sự tham gia của nhiều đồng nghiệp thân thiết như Amee, B Ray, Liên Bỉnh Phát, Đạt G, Quân A.P...
        
    




        
            
            
        
    
    
        
            Trần Phi Vũ chứng tỏ không chỉ mang danh &quot; , &quot;'&quot; , &quot;con trai Trần Khải Ca&quot; , &quot;'&quot; , &quot;
        
        
            
                19:21 6/11/2022
                19:21
                6/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            
            
        
        Trần Phi Vũ đang được mệnh danh là &quot;bạn trai trong mơ&quot; nhờ vai diễn thiên tài Lý Tuấn trong phim ngôn tình &quot;Chiếc bật lửa và váy công chúa&quot;.
        
    




        
            
            
        
    
    
        
            ‘Virus cuồng loạn’ - bộ phim cẩu thả của điện ảnh Việt
        
        
            
                18:40 6/11/2022
                18:40
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            43
            
        
        Dự án điện ảnh kinh dị đầu tay của đạo diễn trẻ Nhất Duy gây thất vọng vì kịch bản chất lượng thấp cùng phong cách làm phim ngô nghê, thiếu tôn trọng người xem.
        
    




        
            
            
        
    
    
        
            Tranh luận việc nữ ca sĩ 14 tuổi biểu diễn vũ đạo gợi cảm
        
        
            
                15:09 6/11/2022
                15:09
                6/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            1
            
        
        CLASS:y có hai thành viên sinh năm 2008. Do đó, việc nhóm chuyển sang phong cách trưởng thành và có nhiều động tác gợi cảm khiến khán giả tranh luận.
        
    




        
            
            
        
    
    
        
            &quot; , &quot;'&quot; , &quot;Bông hồng lai&quot; , &quot;'&quot; , &quot; Patricia Good và đại gia Thái Lan chuẩn bị cho lễ cưới
        
        
            
                14:20 6/11/2022
                14:20
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            9
            
        
        Patricia Good và doanh nhân giàu có Note Vises đính hôn hồi tháng 6. Họ vừa thực hiện các nghi thức dâng hoa và nhận nước thánh tại chùa.
        
    




        
            
            
        
    
    
        
            Hàng ghế đầu Tuần lễ thời trang có còn mất giá vì TikToker tai tiếng
        
        
            
                12:26 6/11/2022
                12:26
                6/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            8
            
        
        Khách mời tại sự kiện thời trang phụ thuộc vào nhiều nguồn. Bên cạnh đó, ban tổ chức Tuần lễ thời trang khuyến khích không mang những điều quá dị hợm đến sự kiện.
        
    




        
            
            
        
    
    
        
            Ngành giải trí Nhật Bản chấn động vì nam ca sĩ qua đời ở tuổi 19
        
        
            
                11:37 6/11/2022
                11:37
                6/11/2022
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            12
            
        
        Nikkan Sports đưa tin nam ca sĩ kiêm diễn viên Yoshi bị tai nạn vào sáng 5/11. Vụ việc khiến anh bị thương nặng và qua đời sau đó.
        
    




        
            
            
        
    
    
        
            Aaron Carter - từ &quot; , &quot;'&quot; , &quot;hoàng tử trong mơ&quot; , &quot;'&quot; , &quot; đến cái chết ở tuổi 35
        
        
            
                11:02 6/11/2022
                11:02
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Sao Hollywood
            
            

            
        
        
            
            
            0
            43
            
        
        Trở thành ngôi sao toàn cầu từ khi còn rất nhỏ, sự nghiệp của Aaron Carter lên &quot;như diều gặp gió&quot;. Tuy nhiên, mặt tối hào quang và bi kịch gia đình khiến anh tụt dốc không phanh.
        
    




        
            
            
        
    
    
        
            Hôn lễ của diễn viên &quot; , &quot;'&quot; , &quot;Tình dục là chuyện nhỏ&quot; , &quot;'&quot; , &quot; và vợ kém 24 tuổi
        
        
            
                10:26 6/11/2022
                10:26
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Hôn lễ của nam diễn viên Choi Seong Guk diễn ra tối 5/11 tại Jongno-gu. Anh và bạn gái quen nhau một năm trước khi về chung một nhà.
        
    




        
            
            
        
    
    
        
            &quot; , &quot;'&quot; , &quot;Trương Phi&quot; , &quot;'&quot; , &quot; chưa biết &quot; , &quot;'&quot; , &quot;Quan Vũ&quot; , &quot;'&quot; , &quot; qua đời
        
        
            
                10:15 6/11/2022
                10:15
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Trong &quot;Tam quốc diễn nghĩa&quot;, khi Quan Vũ qua đời, Trương Phi khóc tới ngất. Song, khi &quot;Quan Vũ&quot; Lục Thụ Minh ra đi, người thân không dám báo &quot;Trương Phi&quot; Lý Tĩnh Phi.
        
    




        
            
            
        
    
    
        
            Angelababy khủng hoảng phiên vị
        
        
            
                09:30 6/11/2022
                09:30
                6/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            
            
        
        Angelababy lép vế trước Nhậm Gia Luân trong phim truyền hình mới &quot;Mộ sắc tâm ước&quot;. Điều này khiến người hâm mộ của cô thất vọng.
        
    




        
            
            
        
    
    
        
            Những ngày cuối đời của Aaron Carter
        
        
            
                09:11 6/11/2022
                09:11
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            46
            
        
        Một tháng trước khi mất, Aaron Carter rao bán căn nhà riêng để &quot;bắt đầu chương mới của cuộc đời&quot;. Mối quan hệ của anh và hôn thê cũng trở nên tồi tệ.
        
    




        
            
            
        
    
    
        
            Người đẹp Trà Vinh cao 1,8 m là tân Hoa khôi Nam Bộ 2022
        
        
            
                09:09 6/11/2022
                09:09
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            4
            
        
        Đêm chung kết cuộc thi Hoa khôi Nam Bộ 2022 được tổ chức tại TP Cần Thơ vừa kết thúc tối 5/11. Kết quả thí sinh Lê Thị Kiều Nhung (Trà Vinh) đoạt vương miện hoa khôi.
        
    




        
            
            
        
    
    
        
            Phim đồng tính và mặt tối &quot; , &quot;'&quot; , &quot;queerbaiting’
        
        
            
                08:31 6/11/2022
                08:31
                6/11/2022
            

            
            
                Phim ảnh
            
            

            
            
                Phim ảnh
            
            

            
        
        
            
            
            0
            7
            
        
        Từng là một địa hạt cực kỳ nhạy cảm, câu chuyện về cộng đồng LGBTQ+ dần có những bước tiếp cận tiến bộ với khán giả đại chúng.
        
    




        
            
            
        
    
    
        
            Son Heung-min mặc đẹp
        
        
            
                08:09 6/11/2022
                08:09
                6/11/2022
            

            
            
                Thời trang
            
            

            
            
                Thời trang
            
            

            
        
        
            
            
            0
            7
            
        
        Không phải ngôi sao giải trí nhưng gu ăn mặc của Son Heung-min chẳng hề kém cạnh. Bên ngoài sân cỏ, anh chính là tín đồ thời trang.
        
    




        
            
            
        
    
    
        
            Aaron Carter qua đời
        
        
            
                08:02 6/11/2022
                08:02
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            76
            
        
        Ca sĩ Aaron Carter qua đời đột ngột tại nhà riêng ở Lancaster, California, Mỹ. Nguyên nhân cái chết của anh vẫn chưa được xác định.
        
    




        
            
            
        
    
    
        
            Tăng Thanh Hà và Louis Nguyễn kỷ niệm 10 năm ngày cưới
        
        
            
                08:02 6/11/2022
                08:02
                6/11/2022
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            16
            
        
        Vợ chồng Tăng Thanh Hà tổ chức bữa tiệc ấm cúng bên người thân, bạn bè để kỷ niệm 10 năm ngày về chung một nhà.
        
    






            
            
                Xem thêm
            
            
        

        
        
            

            
            
    
    
        
        SIGNATURE SERIES
    
    
    
    



        
            
            10:02
            
            
        
    
    
        
            Ca sĩ Bích Phương: &quot; , &quot;'&quot; , &quot;Bản chất tôi là người lười biếng&quot; , &quot;'&quot; , &quot;
        
        
            
                06:08 6/12/2021
                06:08
                6/12/2021
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Bích Phương cho biết cô vốn có tính lười, nên trong một năm đầu tiên dịch bệnh diễn ra, nữ ca sĩ chỉ nằm trong nhà và không làm bất cứ việc gì.
        
    




        
            
            12:28
            
            
        
    
    
        
            Erik: &quot; , &quot;'&quot; , &quot;Tham gia 10 cuộc thi, lần đầu tôi giành quán quân&quot; , &quot;'&quot; , &quot;
        
        
            
                07:33 5/12/2021
                07:33
                5/12/2021
            

            
            
                Âm nhạc
            
            

            
            
                Âm nhạc
            
            

            
        
        
            
            
            0
            
            
        
        Erik vừa giành chiến thắng ở chương trình The Heroes. Nam ca sĩ cho biết anh hạnh phúc khi cuối cùng đã nhận giải quán quân sau nhiều cuộc thi.
        
    




        
            
            14:54
            
            
        
    
    
        
            Ca sĩ Mlee: &quot; , &quot;'&quot; , &quot;Nếu bạn trai đi quá giới hạn, tôi sẽ chia tay&quot; , &quot;'&quot; , &quot;
        
        
            
                06:20 19/9/2021
                06:20
                19/9/2021
            

            
            
                Giải trí
            
            

            
            
                Giải trí
            
            

            
        
        
            
            
            0
            
            
        
        Mlee cho biết cô yêu hết mình nhưng cũng dứt khoát chia tay nếu bạn trai đi quá giới hạn. Nữ ca sĩ cho biết hiện cô độc thân để dồn thời gian cho công việc.
        
    





    
    
    
    
    Xem thêm

            
            
    
    
        
        Sách Nghệ thuật - Giải trí
    
    
    
    



        
            
            
        
    
    
        
            Bà trùm nội y từng đi giao báo kiếm tiền năm 10 tuổi
        
        
            
                20:18 29/10/2022
                20:18
                29/10/2022
            

            
            
                Xuất bản
            
            

            
            
                Sách hay
            
            

            
        
        
            
            
            0
            
            
        
        “Tôi thuyết phục quầy báo nằm trên cùng con phố cho tôi đi giao báo. Lượng báo phải giao rất nhiều, nhưng tôi rất quyết tâm”, Michelle Mone kể trong cuốn tự truyện.
        
    




        
            
            
        
    
    
        
            Có một Marilyn Monroe rất khác
        
        
            
                15:30 17/10/2022
                15:30
                17/10/2022
            

            
            
                Xuất bản
            
            

            
            
                Sách hay
            
            

            
        
        
            
            
            0
            
            
        
        Virginia Woolf đã nói rằng một người phụ nữ muốn tự chủ cần phải có tiền và một căn phòng của riêng mình. Marilyn Monroe trong thời hoàng kim cũng đã có được chốn ấy.
        
    




        
            
            
        
    
    
        
            Lý do Tôn Ngộ Không thường ăn vận quần áo có tấm da cọp
        
        
            
                16:32 20/9/2022
                16:32
                20/9/2022
            

            
            
                Xuất bản
            
            

            
            
                Sách hay
            
            

            
        
        
            
            
            0
            
            
        
        Đã quy y Phật, đi thỉnh kinh mà Tề Thiên còn muốn chơi hàng độc thời trang ư? Thật ra đây là một hình ảnh mang tính ẩn dụ.
        
    





    
    
    
    
    Xem thêm

            

            

            
            
            
            

            
                
                    Nổi bật 48 giờ
                
                
                
                    
                        
                    
                
                
                    
                        Giải trí
                    
                    
                        Thế khó của Trấn Thành
                    
                
                Giới trong nghề nhận định &quot;Bố già&quot; đã đạt được doanh thu &quot;vô tiền khoáng hậu&quot; với hơn 400 tỷ đồng. Dự án phim Tết 2023 của Trấn Thành không dễ vượt qua con số này.
                23:04 CN, 06/11
            
                
                    
                        
                    
                
                
                    
                        Giải trí
                    
                    
                        Nghệ sĩ Trung Quốc đang bị tình dục hóa quá mức khi mặc gợi cảm
                    
                
                &quot;Phái yếu mặc gợi cảm, trang điểm đẹp chỉ vì muốn thể hiện cá tính, sự tự tin chứ không phải đang khiêu gợi đàn ông&quot;, Tống Vũ Kỳ nêu quan điểm.
                11:06 hôm qua
            
                
                    
                        
                    
                
                
                    
                        Giải trí
                    
                    
                        ‘Virus cuồng loạn’ - bộ phim cẩu thả của điện ảnh Việt
                    
                
                Dự án điện ảnh kinh dị đầu tay của đạo diễn trẻ Nhất Duy gây thất vọng vì kịch bản chất lượng thấp cùng phong cách làm phim ngô nghê, thiếu tôn trọng người xem.
                11:40 CN, 06/11
            
                
                    
                        
                    
                
                
                    
                        Giải trí
                    
                    
                        Người yêu cũ khóc nức nở khi Aaron Carter qua đời ở tuổi 35
                    
                
                Melanie Martin bật khóc trước nhà riêng của Aaron Carter sau khi anh qua đời. &quot;Hoàng tử nhạc pop&quot; mất ở tuổi 35 trong sự thương tiếc của bạn bè, đồng nghiệp.
                03:37 CN, 06/11
            
                
                    
                        
                    
                
                
                    
                        Giải trí
                    
                    
                        Selena Gomez bị chỉ trích vô ơn với người cho thận
                    
                
                Tình cảm giữa Selena Gomez và Francia Raisa - người đã hiến thận cho cô - rạn nứt sau khi nữ ca sĩ khẳng định chỉ có Taylor Swift là bạn thân trong ngành giải trí.
                15:05 hôm qua
            
            

            
            Quảng cáo của Adtima
            
        
        
    


&quot;))]</value>
      <webElementGuid>0b33bb47-8936-4000-9018-12e572d918e2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
