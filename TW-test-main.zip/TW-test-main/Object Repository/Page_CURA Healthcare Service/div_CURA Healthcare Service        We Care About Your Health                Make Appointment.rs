<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_CURA Healthcare Service        We Care About Your Health                Make Appointment</name>
   <tag></tag>
   <elementGuidId>ef5c3bba-b753-41f2-ad54-05289b15e005</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.text-vertical-center</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[(text() = '
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    ' or . = '
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>57de90aa-8e21-4beb-a024-96f938d05088</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-vertical-center</value>
      <webElementGuid>25486d63-43a7-4906-ae5a-b65ec7f8771a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    </value>
      <webElementGuid>292efe6e-9bcd-476e-9392-2e61384cd90c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;top&quot;)/div[@class=&quot;text-vertical-center&quot;]</value>
      <webElementGuid>f51d8a98-e2ed-46e5-a6f0-888298c94cc2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    ' or . = '
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    ')]</value>
      <webElementGuid>af7066a4-bd86-4a7f-9843-49d42369d2a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/following::div[1]</value>
      <webElementGuid>74ab973c-6e1b-417b-973e-7757c8f56166</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/following::div[1]</value>
      <webElementGuid>04ccee6f-a825-410f-ae5b-d505ae4db062</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='top']/div</value>
      <webElementGuid>b8c57fa4-bfdc-42b2-bd12-97d960d1c283</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div</value>
      <webElementGuid>a1fe404a-8d1b-4e5e-b719-4eed558afe8a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
