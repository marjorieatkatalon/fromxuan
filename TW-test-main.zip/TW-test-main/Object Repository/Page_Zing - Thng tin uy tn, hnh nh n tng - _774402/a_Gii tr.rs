<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Gii tr</name>
   <tag></tag>
   <elementGuidId>4e32d717-c89e-49b5-b5a0-857988cf7f0f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Giải trí&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//header[@id='zing-header']/div/nav/ul/li[5]/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>7bb312de-08a1-493c-9868-ea2ce6090ee7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/giai-tri.html</value>
      <webElementGuid>8943a9c8-b25d-4101-bb56-e39bf02d1847</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Giải trí</value>
      <webElementGuid>0a72d161-8054-48b4-ab3d-125d4d4f4650</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Giải trí</value>
      <webElementGuid>041a42c4-870a-444f-85f5-5db9210fd10d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;zing-header&quot;)/div[@class=&quot;page-wrapper&quot;]/nav[@class=&quot;category-menu&quot;]/ul[1]/li[@class=&quot;parent giai-tri&quot;]/a[1]</value>
      <webElementGuid>48116288-7b4b-41b3-8738-1d4b75102e4e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='zing-header']/div/nav/ul/li[5]/a</value>
      <webElementGuid>b83d4b9f-173c-4254-bdde-a658a89a41db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Giải trí')]</value>
      <webElementGuid>a7744824-0c63-478b-8f1c-838fe77b7e9a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dinh dưỡng Thể thao'])[1]/following::a[1]</value>
      <webElementGuid>fa2281a5-4908-4a63-aeed-9a8e105f59be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hậu trường'])[1]/following::a[2]</value>
      <webElementGuid>fcce48b2-fcbc-4efd-90ea-691d7e724550</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sao'])[1]/preceding::a[1]</value>
      <webElementGuid>f6853c04-60f9-4ed5-9694-73ccb2afe1ff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Âm nhạc'])[1]/preceding::a[2]</value>
      <webElementGuid>99ff1b4c-cba3-4915-9717-92b706fbfaa8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Giải trí']/parent::*</value>
      <webElementGuid>2810f6d4-fb0f-43e2-afeb-07dc90ea7a73</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/giai-tri.html')]</value>
      <webElementGuid>8cdc23f6-49b3-413c-8bca-2f362b49a230</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/a</value>
      <webElementGuid>355db94b-7b21-4114-916e-5a168e20f92d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/giai-tri.html' and @title = 'Giải trí' and (text() = 'Giải trí' or . = 'Giải trí')]</value>
      <webElementGuid>977b6706-a399-4822-95bd-1bffab631e56</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
